---
title: Tools/traci
permalink: /Tools/traci/
---

# areal.py

# constants.py

This script contains TraCI constant definitions from
<SUMO_HOME\>/src/traci-server/TraCIConstants.h.

# edge.py

# gui.py

# introductionloop.py

# junction.py

# lane.py

# multientryexit.py

# poi.py

# polygon.py

# rebuildConstants.py

# route.py

# simulation.py

# trafficlights.py

# vehicle.py

# vehicletype.py